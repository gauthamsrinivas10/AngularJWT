import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-login-form',
  templateUrl: './login-form.component.html',
  styleUrls: ['./login-form.component.css']
})
export class LoginFormComponent implements OnInit {

  form = {
    email : "",
    password : ""
  }
  constructor(private user : UserService) { }

  ngOnInit(): void {
  }
  loginUser(form : NgForm){
this.user.login(this.form.email , this.form.password)

  }

}
