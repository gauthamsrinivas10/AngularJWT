const express = require("express");
const cors = require("cors")
const SECRET_KEY = "4354534543534534534esdfsfsd"
const jwt = require("jsonwebtoken")
const app = express();
app.use(cors());
app.use(express.json());
app.post("/api/v1/login" , (req, res)=>{
    const { body} = req;
    const {email, password} = body;

    if( email === "abc@edu.co" && password === "1234")
    {
        const token = jwt.sign( {email }, SECRET_KEY)
        res.json( { accessToken : token})
    }

    if( email === "admin@edu.co" && password === "1234")
    {
        const token = jwt.sign( {email , admin : true }, SECRET_KEY)
        res.json( { accessToken : token})
    }
    

})


app.get("/api/v1/products", (req,res)=>{
    const { headers, body }= req;
    const { authorization } = headers;
    try {
const payload = jwt.verify(authorization , SECRET_KEY)
res.json([ { id: 1 , name : "Mock Product"}])
    } catch (error) {
res.status(401).json( {message :  "not authorized"})
    }
})

app.get("/api/v1/products-admin", (req,res)=>{
    const { headers, body }= req;
    const { authorization } = headers;
    try {
const payload = jwt.verify(authorization , SECRET_KEY)
const { admin } = payload;

if(admin ===true ){
    res.json([ { id: 1 , name : "Mock Product admin"}])
}
else 
{
    res.status(401).json( {message :  "not authorized admin"}) 
}

    } catch (error) {

    }
})

app.listen(3000, ()=>{
    console.log("application started at 3000")
})